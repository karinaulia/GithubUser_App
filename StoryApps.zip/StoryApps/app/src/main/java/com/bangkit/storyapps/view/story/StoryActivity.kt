package com.bangkit.storyapps.view.story

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.bangkit.storyapps.R

class StoryActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_story)
    }
}