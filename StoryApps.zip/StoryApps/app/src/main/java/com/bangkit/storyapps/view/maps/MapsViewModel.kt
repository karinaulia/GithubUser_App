package com.bangkit.storyapps.view.maps

import androidx.lifecycle.ViewModel
import com.bangkit.storyapps.data.UserRepository

class MapsViewModel(private val repository: UserRepository) : ViewModel() {
    fun getStoriesWithLocation() = repository.sendStoriesWithLocation()
}